# HotpotQA Experimental Results

## Experiments with 500 random sample

|               Method                |    EM    |    F1    |
|:-----------------------------------:|:--------:|:--------:|
|            Zero-Shot CoT            |   32.6   |   43.9   |
|          w/ Chunk Retrieval         |   55.0   |   70.4   |
|        Self-Ask w/ Retrieval        |   45.1   |   62.2   |
| Decompose w/ Hierarchical Retrieval |   59.3   |   74.0   |
