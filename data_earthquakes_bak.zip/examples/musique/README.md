# MuSiQue Experimental Results

## Experiments with 500 random sample

|               Method                |    EM    |    F1    |
|:-----------------------------------:|:--------:|:--------:|
|            Zero-Shot CoT            |   12.9   |   22.9   |
|          w/ Chunk Retrieval         |   28.7   |   39.1   |
|        Self-Ask w/ Retrieval        |   30.0   |   43.4   |
| Decompose w/ Hierarchical Retrieval |   41.5   |   51.6   |
